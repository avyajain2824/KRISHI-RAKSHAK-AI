# KrishiRakshak AI – Farmer Dashboard

A static HTML/CSS/JavaScript prototype. It can be hosted directly with **GitHub Pages**; no Node.js, npm install, build command, or framework is required.

## Files

- `index.html` – complete website (HTML, CSS and JavaScript are embedded).
- `.nojekyll` – tells GitHub Pages not to run Jekyll processing.
- `.github/workflows/pages.yml` – deploys the repository root to GitHub Pages.
- `.gitignore` – excludes common local files and secrets.

## Deploy with GitHub Pages

1. Create a GitHub repository, for example `KrishiRakshak-AI`.
2. Upload all files and folders from this project. Make sure `index.html` is in the repository root.
3. Open **Settings → Pages** in the repository.
4. Under **Build and deployment → Source**, select **GitHub Actions**.
5. Open the **Actions** tab. The workflow named **Deploy static site to GitHub Pages** should run after you push to the default branch.
6. When it succeeds, open **Settings → Pages** to find the published website URL.
7. For later updates, edit files and push/commit changes. GitHub Actions will deploy again.

No build command or publish subdirectory is needed: the workflow publishes the repository root.

## Local preview

Open `index.html` directly in a modern browser, or run a simple local server from this folder:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000`.

## Important prototype limitations

This repository is a deployable **front-end prototype**, not a production-ready agricultural service.

- **Crop checking:** the uploaded leaf photo is only previewed. The current crop check matches typed symptom keywords; it does not analyse image pixels or identify disease from a photo.
- **Farm assistant:** the unsupported vendor-specific browser SDK hook has been removed. The assistant uses a small local keyword-based fallback. Connect a real AI provider through a server-side API before advertising it as AI-powered.
- **Login and verification:** account data is stored in browser `localStorage`; the verification code is shown on screen for demonstration. This is not secure authentication or SMS OTP. Do not use real farmer accounts or PINs.
- **Weather and map:** displayed readings and locations are sample/static values, not live weather or map services.
- **Suppliers:** the unverified sample supplier contacts have been removed. Add verified local suppliers before publishing this section.
- **Finance and carbon calculations:** these are indicative planning calculations, not audited financial, lending, insurance or carbon-credit assessments.

Do not collect real personal, financial, GPS or farm-sensitive data until secure backend storage, authentication, access controls, privacy notices and appropriate testing are implemented.

## Before production

1. Add a backend (for example, a small API service) and keep API keys on the server, never in public browser JavaScript.
2. Implement secure authentication and database access with authorization rules.
3. Connect a validated crop-image model and test it on locally relevant crop images.
4. Connect a trusted weather provider and verified local supplier directory.
5. Review agronomy content with qualified local agricultural experts.
6. Test on mobile and desktop, including accessibility, privacy and security.

## License

No license is included. Add a license only after deciding how you want others to use this project.
